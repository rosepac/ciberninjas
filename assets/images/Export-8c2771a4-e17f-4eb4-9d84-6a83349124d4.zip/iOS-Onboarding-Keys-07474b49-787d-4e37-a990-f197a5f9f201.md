# iOS Onboarding Keys

Creado Por: Ben Lang
categories: Important,Product,UX
date: Sep 20, 2019 9:01 AM
tags: algo,asco,asqueroso,asqueroste xd,chupala,cosa,fuck,grrr,locura,lol,mierda,perrete,perro,prueba,puta,sacalo,xd
title: iOS Onboarding Keys

# Principles:

# fddd

## vcffgfg

- Mi casa et xD
- Balance friction ('asks') with speed (e.g. number of steps to complete onboarding)
- Only educate users about features that are unique to our product
- Highlight where users can go to learn more
- Highlight how users can easily get in contact if they have questions

# Research competitors:

- [x]  Doc Wizard
- [ ]  Note Pro
- [ ]  Respite

# References:

[User Onboarding | A frequently-updated compendium of web app first-run experiences](https://www.useronboard.com/user-onboarding-teardowns/)