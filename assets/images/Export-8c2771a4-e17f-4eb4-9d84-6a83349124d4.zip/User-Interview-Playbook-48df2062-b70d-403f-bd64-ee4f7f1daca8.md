# User Interview Playbook

Creado Por: Shirley Miao
categories: Research
date: Sep 20, 2019 9:01 AM
tags: fuck,lol

# Goals:

- Test and validate user persona hypotheses
- Test and validate interview playbook

# **Questions:**

- Ask the basics:
    - What's your name? What industry is your company in? How big is your team?
- Understand their pain points around current responsibilities:
    - Are there any pain points when collaborating on a document? How about when sharing documents? Ask for elaboration and concrete examples.
- Note down their experience with current solutions:
    - What products are you currently using? How are they fulfilling your needs? Where are they falling short?

# References for user interviews:

[Never Ask What They Want - 3 Better Questions to Ask in User Interviews](https://medium.com/user-research/never-ask-what-they-want-3-better-questions-to-ask-in-user-interviews-aeddd2a2101e)