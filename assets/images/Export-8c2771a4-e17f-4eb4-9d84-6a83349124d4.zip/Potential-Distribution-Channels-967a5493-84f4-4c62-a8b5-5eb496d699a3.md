# Potential Distribution Channels

Creado Por: Jen Jackson
categories: Important,Marketing
date: Sep 20, 2019 9:01 AM

# Acquisition Loops:

- B2B SEO content loop
- Viral page invite loop
- Viral team invite loop

# Linear Channels:

- PR

    [How To Get Press for Your Startup: The Complete Guide](https://medium.com/startup-grind/how-to-get-press-for-your-startup-the-complete-guide-b79c57318113)

- Social

    [15 Tips to Grow a Social-Media Audience for Your Startup](https://www.entrepreneur.com/article/253858)