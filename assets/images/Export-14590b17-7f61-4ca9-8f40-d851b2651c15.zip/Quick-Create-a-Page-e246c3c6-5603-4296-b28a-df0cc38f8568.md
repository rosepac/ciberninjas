# Quick Create a Page

Creado Por: Camille Ricketts
categories: Product
date: Sep 20, 2019 9:01 AM

# Principles

- Creating a new page should be as seamless as possible
- There should be a number of ways to create a page that fits different contexts

---

# Ways to create a new page on desktop:

- [ ]  Keyboard shortcut
- [ ]  Via left sidebar
- [ ]  Via the [+] button in the document
- [ ]  Copy and paste

# Ways to create a new page on mobile:

- [ ]  Force touch
- [ ]  Via left sidebar
- [ ]  Copy and paste